<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to CodeIgniter 4!</title>
    <meta name="description" content="The small framework with powerful features">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="/favicon.ico">

    <!-- STYLES -->

    <style {csp-style-nonce}>
     .wrap{
	background: blue;
	width: 900px;
	margin: 10px auto;
}
 
/*bagian header*/
.wrap .header{
	background: green;
	/*height: 50px;*/
	padding: 2px 10px;
}
 
/*akhir header*/
 
/*bagian menu*/
.wrap .menu{
	background: yellow;
}
 
.wrap .menu ul{
	padding: 0;
	margin: 0;
	background: yellow;
	overflow: hidden;
}
 
.wrap .menu ul li{
	float: left;
	list-style-type: none;
	padding: 10px;
}
/*akhir menu*/
 
.clear{
	clear: both;
}
 
.badan{
	height: 450px;
}
/*bagian sidebar*/
.wrap .badan .sidebar{
	background: orange;
	float: left;	
	width: 25%;
	height: 100%;
}
 
/*akhir sidebar*/
 
.wrap .badan .content{
	background: red;
	float: left;
	height: 100%;
	width: 75%;	
}
 
.wrap .footer{
	width: 100%;
	padding: 10px;
}
    </style>
</head>
<body>

<!-- HEADER: MENU + HEROE SECTION -->
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="wrap">
		<div class="header">			
			<h1 align ="center" >Rest Server</h1>
			<p align ="center">Suci Aprianti Ratnadila - Muhammad Raffi Mustari - Muhammad Ikhsan Muttaqin</p>
		</div>
		<div class="menu">
			
		</div>
		<div class="badan">			
			<div class="sidebar">
				sidebar
				<h1>API Beer & Drank</h1>
			</div>
			<div class="content">
				content
                <h1>Silahkan Ambil Data "/minuman"</h1>
			</div>
		</div>
		<div class="clear"></div>
		<div class="footer">
			footer
		</div>
	</div>
</body>
</html>
</body>
</html>
